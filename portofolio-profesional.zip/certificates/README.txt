CARA MENGISI 30 SERTIFIKAT

Masukkan gambar sertifikat ke folder certificates ini dan gunakan nama:
certificate-01.jpg
certificate-02.jpg
...
certificate-30.jpg

Pastikan ekstensi file .jpg. Jika gambar kamu .png atau .webp, ubah nama file di folder dan bagian src serta href kartu terkait di certificates.html.

Judul sertifikat bisa diganti dengan mengedit teks "Certificate 01", "Certificate 02", dan seterusnya pada certificates.html.
